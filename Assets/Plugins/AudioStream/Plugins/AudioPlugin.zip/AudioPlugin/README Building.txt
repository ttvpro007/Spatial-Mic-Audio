This is needed only if you want to build/examine 'AudioStreamOutputDevice' native mixer plugin (otherwise built binaries are shipped with the asset in 'AudioStream/Plugins')
The project is based on official Unity native audio plugins SDK : https://github.com/Unity-Technologies/NativeAudioPlugins

== This setup corresponds to cca FMOD 2.02.04 version (around 2021/2022)


Place 'AudioPlugin' folder next to the 'Assets' folder in the project directory (- not into it -)

Solution/project files are in VisualStudio/Xcode folders (Linux not implemented/tested so far).

FMOD_Windows/FMOD_macOS contain the contents of the 'core' directory from FMOD Engine install (e.g. on Windows C:\Program Files (x86)\FMOD SoundSystem\FMOD Studio API Windows\api\core ).
'lib' and 'inc' folders are necessary

^ FMOD Engine should be manually downloaded and installed by user to keep all things perfectly legal.


Visual Studio:
- built with VS 2019
- solution contains both 64- and 32- bits configurations
- post build step is run which after successfull build copies the plugin and respective fmod{L}.dll into ..\..\Assets\AudioStream\Plugins\x86_64 or ..\..\Assets\AudioStream\Plugins\x86 depending on chosen configuration
- Release version is recommended


Xcode:
- built with Xcode 10.2 (but newer versions shoudl work)
- recommended to use New Build System ( File -> Project Settings ) and build into Project-relative location
- all build artefacts are then created in 'DerivedData' folder relative/next to the project folder
- copy the result in 'DerivedData/AudioPluginAudioStreamOutputDevice/Build/Products/Release/AudioPluginAudioStreamOutputDevice.bundle'
into 'AudioStream/Plugins'
(Release build can be done by building for Profiling/Archiving)
- libfmod.dylib from FMOD low level package needs to be placed next to the bundle

The above is recommended doing with Unity closed since it gets hold of native plugins intensively.
