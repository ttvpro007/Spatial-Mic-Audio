// (c) 2016-2022 Martin Cvengros. All rights reserved. Redistribution of source code without permission not allowed.
// uses FMOD by Firelight Technologies Pty Ltd

#pragma once
#include "Plugin_AudioStreamOutputDevice.h"

namespace AudioStreamOutputDevice
{
    // Output - FMOD Systems
    static std::map<UInt32, FMODOutputDevice*> systems;
    static AudioPluginUtil::Mutex mMutex;   // pcmbuffers sync feed/stop
    /// <summary>
    /// 
    /// </summary>
    /// <param name="data"></param>
    /// <param name="inbuffer"></param>
    /// <param name="length"></param>
    /// <param name="inchannels"></param>
    /// <param name="samplerate"></param>
    void ProcessCallbackForDevice(EffectData *data, float* inbuffer, unsigned int length, int inchannels, UInt32 samplerate);
    /// <summary>
    /// 
    /// </summary>
    /// <param name="data"></param>
    // void ReleaseDevice(EffectData* data);
    /// <summary>
    /// 
    /// </summary>
    /// <param name="data"></param>
    void MuteSound(EffectData *data);
    /// <summary>
    /// 
    /// </summary>
    /// <param name="data"></param>
    void UnmuteSound(EffectData* data);
    /// <summary>
    /// 
    /// </summary>
    /// <param name="data"></param>
    void StartSound(EffectData* data, int inchannels, UInt32 insamplerate);
    /// <summary>
    /// 
    /// </summary>
    /// <param name="data"></param>
    void StopSound(EffectData* data);
    /// <summary>
    /// 
    /// </summary>
    void DevicesChanged();
    /// <summary>
    /// 
    /// </summary>
    void ReleaseAllDevices();
}
