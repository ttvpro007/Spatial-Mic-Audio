/*===============================================================================================
	FMOD interface
	Copyright (c), Firelight Technologies Pty, Ltd 2004-2019.
 ===============================================================================================*/

 #pragma once

#include "fmod.h"

#include <stddef.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <assert.h>

#define NUM_COLUMNS 50
#define NUM_ROWS 25

#ifndef Common_Sin
#define Common_Sin sin
#endif

#ifndef Common_snprintf
#define Common_snprintf snprintf
#endif

#ifndef Common_vsnprintf
#define Common_vsnprintf vsnprintf
#endif

/* Cross platform functions (common) */
void Common_Format(char *buffer, int bufferSize, const char *formatString...);
void Common_Fatal(const char *format, ...);
void Common_Draw(const char *format, ...);

void ERRCHECK_fn(FMOD_RESULT result, const char *file, int line);
#define ERRCHECK(_result) ERRCHECK_fn(_result, __FILE__, __LINE__)
#define Common_Max(_a, _b) ((_a) > (_b) ? (_a) : (_b))
#define Common_Min(_a, _b) ((_a) < (_b) ? (_a) : (_b))
#define Common_Clamp(_min, _val, _max) ((_val) < (_min) ? (_min) : ((_val) > (_max) ? (_max) : (_val)))
