// (c) 2016-2022 Martin Cvengros. All rights reserved. Redistribution of source code without permission not allowed.
// uses FMOD by Firelight Technologies Pty Ltd

#include "FMODOutputDevice.h"
#include <algorithm>
#if !PLATFORM_WIN
#include <unistd.h> // macOS usleep, clang
#endif

namespace AudioStreamOutputDevice
{
    // 7.1 - 384000 floats requested
    // some reserve
    static std::map<FMOD::Sound*, AudioPluginUtil::RingBuffer<1000000>*> pcmbuffers;

    FMOD_RESULT F_CALLBACK pcmreadcallback(FMOD_SOUND* sound, void* data, unsigned int datalen)
    {
        float* fdata = (float*)data;
        auto length = datalen >> 2; // sizeof(float) == 4

        memset(data, 0, datalen);

        void* reads = 0;
        ((FMOD::Sound*)sound)->getUserData((void**)&reads);

        if (!reads)
            return FMOD_OK;

        auto it = pcmbuffers.find((FMOD::Sound*)sound);
        if (it == pcmbuffers.end())
            return FMOD_OK;

        auto pcmbuffer = it->second;
        if (pcmbuffer)
            for (int n = 0; n < length; n++)
                pcmbuffer->Read(fdata[n]);

        return FMOD_OK;
    }

    FMOD_RESULT F_CALLBACK pcmsetposcallback(FMOD_SOUND* /*sound*/, int /*subsound*/, unsigned int /*position*/, FMOD_TIMEUNIT /*postype*/)
    {
        /*
        This is useful if the user calls Channel::setPosition and you want to seek your data accordingly.
        */
        return FMOD_OK;
    }


    FMOD_RESULT F_CALLBACK SystemCallback(FMOD_SYSTEM* system, FMOD_SYSTEM_CALLBACK_TYPE type, void* commanddata1, void* commanddata2, void* userdata)
    {
        if (
            (type & FMOD_SYSTEM_CALLBACK_RECORDLISTCHANGED)
            )
        {
            if (userdata)
                ((FMODOutputDevice*)userdata)->Invoke_Callback();
        }

        return FMOD_OK;
    }


    FMODOutputDevice::FMODOutputDevice(UInt32 outputDeviceID, UInt32 samplerate, void(*notification_cb)())
    {
        /*
        Create a System object and initialize.
        */
        result = FMOD::System_Create(&system);
        ERRCHECK(result);

        result = system->getVersion(&version);
        ERRCHECK(result);

        if (version < FMOD_VERSION)
        {
            Common_Fatal("FMOD lib version %08x doesn't match header version %08x", version, FMOD_VERSION);
        }

        // Windows PC: 1024 / 4
        // unsigned int dlenght;
        // int dcount;
        // system->getDSPBufferSize(&dlenght, &dcount);
        // ERRCHECK(result);

        // result = system->setDSPBufferSize(dspBLength, dspBCount);
        // ERRCHECK(result);

		result = system->setSoftwareFormat(samplerate, FMOD_SPEAKERMODE_DEFAULT, 0);
		ERRCHECK(result);

        result = system->init(10, FMOD_INIT_NORMAL, NULL);
        ERRCHECK(result);

        if (notification_cb)
        {
            this->notifcation_callback = notification_cb;

            result = system->setDriver(0);
            ERRCHECK(result);

            // CB instance
            result = system->setUserData((void*)this);
            ERRCHECK(result);
            
            // install callback for FMOD_SYSTEM_CALLBACK_RECORDLISTCHANGED only
            // - it looks like that captures also changes on output devices (capture driver?)
            // (FMOD_SYSTEM_CALLBACK_DEVICELISTCHANGED doesn't capture e.g. changing default output)
            // each notification is processed separately - so there woudl be also two callbacks..
            
            result = system->setCallback(&SystemCallback, FMOD_SYSTEM_CALLBACK_RECORDLISTCHANGED);
            ERRCHECK(result);
        }
        else
        {
            result = system->setDriver(outputDeviceID);
            ERRCHECK(result);
        }
    }

    FMODOutputDevice::~FMODOutputDevice()
    {
        if (!this->system)
            return;
        /*
        Shut down
        */

        // update the system before release to possibly not hang up on system close
        this->Update();

        while(this->sounds.size() > 0)
            this->StopSound(this->sounds.front());

#if PLATFORM_OSX
        usleep(50000);
#else
        Sleep(50);
#endif

        // AudioDeviceStop - CoreAudio`HALB_Mutex::Lock
#if !PLATFORM_OSX
        // This will internally call System::close, so calling System::close before this function is not necessary.
        result = this->system->release();
        ERRCHECK(result);
#endif

        this->system = NULL;
    }

    void FMODOutputDevice::MuteSound(FMOD::Sound* sound)
    {
        pcmbuffers[sound]->SyncWritePos();
        
        result = sound->setUserData(NULL);
        ERRCHECK(result);
    }

    void FMODOutputDevice::UnmuteSound(FMOD::Sound* sound)
    {
        result = sound->setUserData((void*)this);
        ERRCHECK(result);
    }

    void FMODOutputDevice::StartSound(FMOD::Sound** sound, int inchannels, UInt32 insamplerate)
    {
        // create sound

        // directly affects latency, can't be a second (insamplerate) long..
        auto decodebuffersize = 1024; // screw this and hardcode it on windows for now..  FastMax(insamplerate / 40.0f, 1024);

        /*
        Create and play the sound.
        */
        FMOD_CREATESOUNDEXINFO  exinfo;

        memset(&exinfo, 0, sizeof(FMOD_CREATESOUNDEXINFO));
        exinfo.cbsize = sizeof(FMOD_CREATESOUNDEXINFO);                                         /* Required. */
        exinfo.numchannels = inchannels;                                                        /* Number of channels in the sound. */
        exinfo.defaultfrequency = insamplerate;                                                 /* Default playback rate of sound. */
        // v this is directly latency related
        exinfo.decodebuffersize = decodebuffersize;                                             /* Chunk size of stream update in samples. This will be the amount of data passed to the user callback. */
        exinfo.length = exinfo.defaultfrequency * exinfo.numchannels * sizeof(float);           /* Length of PCM data in bytes of whole song (for Sound::getLength) */
        exinfo.format = FMOD_SOUND_FORMAT_PCMFLOAT;                                             /* Data format of sound. */
        exinfo.pcmreadcallback = pcmreadcallback;                                               /* User callback for reading. */
        exinfo.pcmsetposcallback = pcmsetposcallback;                                           /* User callback for seeking. */
        exinfo.userdata = (void*)this;

        FMOD_MODE   mode = FMOD_OPENUSER | FMOD_LOOP_NORMAL | FMOD_CREATESTREAM;

        result = system->createSound(0, mode, &exinfo, sound);
        ERRCHECK(result);

        pcmbuffers[*sound] = new AudioPluginUtil::RingBuffer<1000000>();

        FMOD::Channel* channel;
        result = system->playSound(*sound, 0, 0, &channel);
        ERRCHECK(result);

        this->sounds.push_back(*sound);
    }

    void FMODOutputDevice::StopSound(FMOD::Sound* sound)
    {
        auto it = std::find(this->sounds.begin(), this->sounds.end(), sound);
        if (it != this->sounds.end())
        {
            result = (*it)->release();
            ERRCHECK(result);

#if PLATFORM_OSX
            usleep(50000);
#else
            Sleep(50);
#endif
            this->Update();

            // delete buffer
            auto pcmbit = pcmbuffers.find(*it);
            if (pcmbit != pcmbuffers.end())
            {
                delete pcmbit->second;
                pcmbuffers.erase(*it);
            }

            this->sounds.remove(*it);
        }
    }

    bool FMODOutputDevice::SoundValid(FMOD::Sound* sound)
    {
        return std::find(this->sounds.begin(), this->sounds.end(), sound) != this->sounds.end();
    }

    void FMODOutputDevice::Update()
    {
        result = system->update();
        ERRCHECK(result);
    }

    void FMODOutputDevice::Feed(FMOD::Sound* sound, const float* input, unsigned int length)
    {
        auto pcmbuffer = pcmbuffers[sound];
        if (pcmbuffer)
            for (unsigned int n = 0; n < length; n++)
                pcmbuffer->Feed(input[n]);
    };

    void FMODOutputDevice::Invoke_Callback()
    {
        this->notifcation_callback();
    }
}
