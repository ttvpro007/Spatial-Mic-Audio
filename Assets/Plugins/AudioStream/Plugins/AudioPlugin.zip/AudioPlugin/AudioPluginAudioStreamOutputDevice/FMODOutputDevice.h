// (c) 2016-2022 Martin Cvengros. All rights reserved. Redistribution of source code without permission not allowed.
// uses FMOD by Firelight Technologies Pty Ltd

#pragma once

#if defined(WIN32) || defined(_WIN32) || defined(__WIN32__) || defined(_WIN64)
#include "..\AudioPluginUtil.h" // this has platforms abstractions apart from plugin convenience macros, mainly
#include "..\AudioPluginInterface.h"
#else
#include "AudioPluginUtil.h"
#include "AudioPluginInterface.h" // Xcode added files are found
#endif
#include "fmod.hpp"
#include "fmod_common.h"
#include <list>
#include <map>
#include <iterator>
using namespace std;

namespace AudioStreamOutputDevice
{
    class FMODOutputDevice
    {
    public:
        FMODOutputDevice(UInt32 outputDeviceID, UInt32 samplerate, void(*notification_cb)() );
        ~FMODOutputDevice();

        void Update();

        void Feed(FMOD::Sound* sound, const float* input, unsigned int length);

        void MuteSound(FMOD::Sound* sound);
        void UnmuteSound(FMOD::Sound* sound);

        void StartSound(FMOD::Sound** sound, int inchannels, UInt32 insamplerate);
        void StopSound(FMOD::Sound* sound);

        void Invoke_Callback();

        bool SoundValid(FMOD::Sound* sound);

    private:
        FMOD::System    *system = NULL;
        list<FMOD::Sound*> sounds;
        FMOD_RESULT     result = FMOD_OK;
        unsigned int    version = 0;
        void(*notifcation_callback)() = NULL;
    };
}