// (c) 2016-2022 Martin Cvengros. All rights reserved. Redistribution of source code without permission not allowed.
// uses FMOD by Firelight Technologies Pty Ltd

// TODO: ERRCHECK does nothing when error

#include "Plugin_AudioStreamOutputDevice.h"
#include "FMODSystemsManager.h"

namespace AudioStreamOutputDevice
{
#pragma region devices changes notification

    /// <summary>
    /// single system (0) for notifications about devices changes 
    /// </summary>
    static FMODOutputDevice* notification_system = NULL;

#pragma endregion

    int InternalRegisterEffectDefinition(UnityAudioEffectDefinition& definition)
    {
        int numparams = P_NUM;
        definition.paramdefs = new UnityAudioParameterDefinition[numparams];
        // name length *MUST* fit below 16 characters (char[16] in struct definition) <- runtime assert otherwise..
        AudioPluginUtil::RegisterParameter(definition, "OutputDevice ID", "(ID)", 0, 255, 0, 1, 1, P_OUTPUTDEVICEID, "System's output device ID that the input signal will be played on.\r\n\r\nYou can change output device while playing");
        AudioPluginUtil::RegisterParameter(definition, "Passthru", "(true/false)", 0, 1, 0, 1, 1, P_PASSTHRU, "Pass the signal along in the mixer after redirection/playing on an output device if true.\r\n\r\nDefault false (will be played on selected output and then disappear from the mixer/group)\r\n\r\nCan be changed while playing");
        // RegisterParameter(definition, "DSPBufferLength", "b", 64, 4096, 1024, 1.0f, 1.0f, P_DSPBUFFERLENGTH, "Changing this should only be needed when using Unity's Best latency audio setting and experiencing pops/dropouts in the audio, or having troubles playing on certain outputs - can be left at default (1024/4) otherwise\r\n\r\n- you can try to lower/match default FMOD latency which is used for redirection to Unity ones - DSP buffer size should be 256/4 for Unity's Best latency setting\r\nNote: You probably won't get rid of them entirely, esp. in the Editor - IL2CPP build on 4.6 runtime might help further, but unfortunately it doesn't seem to help in all cases - use other than Best latency if possible in that case\r\n\r\nPlease restart redirection manually after changing this (you can stop play mode or change output device id to do this)");
        // RegisterParameter(definition, "DSPBufferCount", "", 2, 16, 4, 1.0f, 1.0f, P_DSPBUFFERCOUNT, "Changing this should only be needed when using Unity's Best latency audio setting and experiencing pops/dropouts in the audio, or having troubles playing on certain outputs - can be left at default (1024/4) otherwise\r\n\r\n- you can try to lower/match default FMOD latency which is used for redirection to Unity ones - DSP buffer size should be 256/4 for Unity's Best latency setting\r\nNote: You probably won't get rid of them entirely, esp. in the Editor - IL2CPP build on 4.6 runtime might help further, but unfortunately it doesn't seem to help in all cases - use other than Best latency if possible in that case\r\n\r\nPlease restart redirection manually after changing this (you can stop play mode or change output device id to do this)");

        return numparams;
    }

    UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK CreateCallback(UnityAudioEffectState* state)
    {
        EffectData* data = new EffectData;
        memset(data, 0, sizeof(EffectData));

        AudioPluginUtil::InitParametersFromDefinitions(InternalRegisterEffectDefinition, data->parameters);

        state->effectdata = data;

        if(!notification_system)
            notification_system = new FMODOutputDevice(0, 48000, &DevicesChanged);

        return UNITY_AUDIODSP_OK;
    }

    UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK ReleaseCallback(UnityAudioEffectState* state)
    {
        EffectData* data = state->GetEffectData<EffectData>();
        delete data;

        ReleaseAllDevices();

        if (notification_system)
        {
            delete notification_system;
            notification_system = NULL;
        }

        return UNITY_AUDIODSP_OK;
    }

    UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK SetFloatParameterCallback(UnityAudioEffectState* state, int index, float value)
    {
        EffectData* data = state->GetEffectData<EffectData>();

        if (index >= P_NUM)
            return UNITY_AUDIODSP_ERR_UNSUPPORTED;

        // store (rounded) value in the context to be retrieved by processing

        switch (index)
        {
        case P_OUTPUTDEVICEID:
        {
            // stop current sound on change
            // (releases FMOD system if necessary; fmod is created lazily later from ProcessCallback)
            if ((UInt32)value != data->parameters[index])
                StopSound(data);
        }

        break;

        default:
            break;
        }

        data->parameters[index] = (UInt32)value;

        return UNITY_AUDIODSP_OK;
    }

    // looks like this is for (custom) UI - ignore for now
    UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK GetFloatParameterCallback(UnityAudioEffectState* state, int index, float* value, char *valuestr)
    {
        EffectData* data = state->GetEffectData<EffectData>();
        if (index >= P_NUM)
            return UNITY_AUDIODSP_ERR_UNSUPPORTED;
        if (value != NULL)
            *value = data->parameters[index];
        if (valuestr != NULL)
            valuestr[0] = 0;
        return UNITY_AUDIODSP_OK;
    }

    int UNITY_AUDIODSP_CALLBACK GetFloatBufferCallback(UnityAudioEffectState* state, const char* name, float* buffer, int numsamples)
    {
        return UNITY_AUDIODSP_OK;
    }

    extern bool invalidate_devices;
    UNITY_AUDIODSP_RESULT UNITY_AUDIODSP_CALLBACK ProcessCallback(UnityAudioEffectState* state, float* inbuffer, float* outbuffer, unsigned int length, int inchannels, int outchannels)
    {
        if (notification_system)
            notification_system->Update();

        EffectData* data = state->GetEffectData<EffectData>();

        if (invalidate_devices)
        {
            invalidate_devices = false;
            ReleaseAllDevices();
        }

        if (
            !(state->flags & UnityAudioEffectStateFlags_IsPlaying)
            || (state->flags & (UnityAudioEffectStateFlags_IsMuted | UnityAudioEffectStateFlags_IsPaused))
            )
        {
            memset(outbuffer, 0, sizeof(float) * length * inchannels);

            if (data->sound)
                MuteSound(data);

            // always update system if created
            auto outputDeviceID = data->parameters[P_OUTPUTDEVICEID];
            auto system = systems.find(outputDeviceID);
            if (system != systems.end())
                system->second->Update();

            return UNITY_AUDIODSP_OK;
        }
        
        if (data->sound)
            UnmuteSound(data);

        // forward processing
        ProcessCallbackForDevice(data, inbuffer, length, inchannels, state->samplerate);

        auto passthru = (bool)data->parameters[P_PASSTHRU];
        if (passthru)
            memcpy(outbuffer, inbuffer, sizeof(float) * length * inchannels);
        else
            memset(outbuffer, 0, sizeof(float) * length * inchannels);

        return UNITY_AUDIODSP_OK;
    }
}
