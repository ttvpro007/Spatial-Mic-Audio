// (c) 2016-2022 Martin Cvengros. All rights reserved. Redistribution of source code without permission not allowed.
// uses FMOD by Firelight Technologies Pty Ltd

#pragma once
#include "FMODOutputDevice.h"

namespace AudioStreamOutputDevice
{
    enum Param
    {
        P_OUTPUTDEVICEID
        , P_PASSTHRU
        // , P_DSPBUFFERLENGTH
        // , P_DSPBUFFERCOUNT
        , P_NUM
    };
    /// <summary>
    /// 
    /// </summary>
    struct EffectData
    {
        /// <summary>
        /// User/Unity mixer effect parameters
        /// </summary>
        float parameters[P_NUM];
        /// <summary>
        /// FMOD sound on system for parameters[P_OUTPUTDEVICEID] 
        /// </summary>
        FMOD::Sound* sound;
    };
}
