// (c) 2016-2022 Martin Cvengros. All rights reserved. Redistribution of source code without permission not allowed.
// uses FMOD by Firelight Technologies Pty Ltd

#include "FMODSystemsManager.h"
#include "FMODOutputDevice.h"
#include <map>

namespace AudioStreamOutputDevice
{
    void ProcessCallbackForDevice(EffectData *data, float* inbuffer, unsigned int length, int inchannels, UInt32 samplerate)
    {
        AudioPluginUtil::MutexScopeLock m1(mMutex);

        auto outputDeviceID = data->parameters[P_OUTPUTDEVICEID];

        auto system = systems.find(outputDeviceID);
		if (system == systems.end())
			systems[outputDeviceID] = new FMODOutputDevice(outputDeviceID, samplerate, NULL);

        systems[outputDeviceID]->Update();

        if (data->sound == NULL
            || !systems[outputDeviceID]->SoundValid(data->sound)
            )
        {
            StartSound(data, inchannels, samplerate);
            systems[outputDeviceID]->Update();
        }

        // forward the inbuffer
        systems[outputDeviceID]->Feed(data->sound, inbuffer, length * inchannels);
    }

    void MuteSound(EffectData *data)
    {
        AudioPluginUtil::MutexScopeLock m1(mMutex);

        auto outputDeviceID = data->parameters[P_OUTPUTDEVICEID];

        auto system = systems.find(outputDeviceID);
        if (system != systems.end())
        {
            system->second->MuteSound(data->sound);
        }
    }

    void UnmuteSound(EffectData* data)
    {
        AudioPluginUtil::MutexScopeLock m1(mMutex);

        auto outputDeviceID = data->parameters[P_OUTPUTDEVICEID];

        auto system = systems.find(outputDeviceID);
        if (system != systems.end())
        {
            system->second->UnmuteSound(data->sound);
        }
    }

    //void ReleaseDevice(EffectData* data)
    //{
    //    AudioPluginUtil::MutexScopeLock m1(mMutex);

    //    auto outputDeviceID = data->parameters[P_OUTPUTDEVICEID];

    //    auto system = systems.find(outputDeviceID);
    //    if (system != systems.end())
    //    {
    //        delete system->second;
    //        systems.erase(system);
    //    }
    //}

    void StartSound(EffectData* data, int inchannels, UInt32 insamplerate)
    {
        AudioPluginUtil::MutexScopeLock m1(mMutex);

        auto outputDeviceID = data->parameters[P_OUTPUTDEVICEID];
        auto system = systems.find(outputDeviceID);
        if (system != systems.end())
        {
            system->second->StartSound(&data->sound, inchannels, insamplerate);
        }
    }

    void StopSound(EffectData* data)
    {
        AudioPluginUtil::MutexScopeLock m1(mMutex);

        auto outputDeviceID = data->parameters[P_OUTPUTDEVICEID];
        auto system = systems.find(outputDeviceID);
        if (system != systems.end())
        {
            system->second->StopSound(data->sound);
            data->sound = NULL;
        }
    }

    bool invalidate_devices = false;
    void DevicesChanged()
    {
#if !PLATFORM_OSX
        invalidate_devices = true;
#endif
    }

    void ReleaseAllDevices()
    {
        AudioPluginUtil::MutexScopeLock m1(mMutex);

        for (auto it = systems.begin(); it != systems.end(); ++it)
            delete it->second;

        systems.clear();
    }
}
